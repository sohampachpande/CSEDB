import pandas as pd
import requests
from bs4 import BeautifulSoup
import string
import re
import pandas as pd
from nltk.probability import FreqDist, MLEProbDist
import string 
import pickle
import numpy as np
import time
import json
import os
import sys

def htm(link):
    response = requests.get(link)
    html = response.content
    htm = BeautifulSoup(html, "lxml")
    return htm

link = 'https://www.aclweb.org/anthology/'
link_tags = htm(link).findAll('tr', {'class' : 'border-left border-right'})

a_tag_list = []
for i in link_tags:
	if i.a.text == 'ANN':
		a_tag_list += i.findAll('a')
	else:
		a_tag_list.append(i.a)

a_tag_list = [['https://www.aclweb.org/anthology/' + i['href'][11:], i.text] for i in a_tag_list]

with open('Tag_List.pickle', 'wb') as handle:
    pickle.dump(a_tag_list, handle, protocol=pickle.HIGHEST_PROTOCOL)

# with open('filename.pickle', 'rb') as handle:
#     b = pickle.load(handle)

######################
def get_volume(link):
	global link_list
	content = htm(link).findAll('div', {'class':'row'})

	dict_conf = {}
	for i in content:
		year = i.find('div',{'class','col-sm-1'}).text
		dict_conf[year] = {}

		for_code = i.ul
		list_li = for_code.findAll('li')
		# pattern = re.compile("[\S]")
		for j in list_li:
			try:
				code = j.span.text
				code = re.findall('\[.*\]',code)[0][1:-1]

				link = 'https://www.aclweb.org/anthology/' + j.a['href'][11:]
				name = j.a.text

				dict_conf[year][code] = [link, name]
				link_list.append(link)
			except:
				pass

	return dict_conf

link_list = []
dict_main = {}
for i in a_tag_list:
	try:
		dict_main[i[1]] = get_volume(i[0])
	except:
		print i[0]

	break

with open('Conference_Tree.pickle', 'wb') as handle:
    pickle.dump(dict_main, handle, protocol=pickle.HIGHEST_PROTOCOL)

#######################
def get_pdf(link, name):
	r = requests.get(link)
	with open("files/%s.pdf"%(name),'wb') as f: 
	    f.write(r.content)

def get_pdf_link(link, paper_info):
	content = htm(link).find('div', {'class':'row acl-paper-details'})
	main_content = content.next_sibling.next_sibling.findAll('p')

	for i in main_content[1:]:
		row = i.find('span',{'class':'mr-2'})
		code = i.find('span',{'class':'text-muted'}).text[1:-2]
		paper_info[code] = {}

		pdf_link = row.find('a',{'title':"Open PDF"})['href']
		paper_info[code]['PDF'] = pdf_link

		bib_link = row.find('a',{'title':"Export to BibTeX"})['href']
		paper_info[code]['Bib'] = 'https://www.aclweb.org/anthology/' + bib_link[11:]

		try:
			video_link = row.find('a',{'title':"Video"})['href']
			paper_info[code]['Video'] = video_link
		except:
			pass

		try:
			note_link = row.find('a',{'title':"Note"})['href']
			paper_info[code]['Note'] = note_link
		except:
			pass

		try:
			poster_link = row.find('a',{'title':"Poster"})['href']
			paper_info[code]['Poster'] = poster_link
		except:
			pass

		try:	
			software_link = row.find('a',{'title':"Software"})['href']
			paper_info[code]['Software'] = software_link
		except:
			pass

		try:
			presentation_link = row.find('a',{'title':"Presentation"})['href']
			paper_info[code]['Presentation'] = presentation_link
		except:
			pass

		next_row = row.next_sibling
		title = next_row.find('a', {'class':'align-middle'})

		title_link = 'https://www.aclweb.org/anthology/' + title['href'][11:]
		paper_info[code]['Paper Link'] = title_link 

		title_text = title.text
		paper_info[code]['Title'] = title_text 


		exists = os.path.isfile('files/%s.pdf'%(code))
		if exists:
			pass
		else:
			get_pdf(pdf_link, code)

paper_info = {}
for i in link_list:
	get_pdf_link(i, paper_info)

with open('Paper_Meta_Data.pickle', 'wb') as handle:
    pickle.dump(paper_info, handle, protocol=pickle.HIGHEST_PROTOCOL)







