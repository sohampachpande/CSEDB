import os
import sys
directory = "input/"
temp_dir = "temp/"
import subprocess
import threading
from subprocess import Popen, PIPE
import Aff_new
import Email_new
import TitleAuthor_parse
import chunk
import operator
import glob
import xml.etree.ElementTree as ET
import Secmapping
import printAuthor
import printnameformap
import authorEmailMapping
import cit_final
import footnotes
import tables_figures
import url
import generate_xml
# import xmlParsing
# import testFoldedData
# import genrateCoraxml
import time

def runScript():

    copyTime = 0
    pdftoxmltime = 0
    parseTime = 0
    footnotestime = 0
    tables_figures_time = 0
    urltime = 0
    cit2reftime = 0
    chunk1time = 0
    chunk2time = 0
    secMapTime = 0
    emailTime = 0
    affTime = 0
    titleTime = 0
    authorTime = 0
    mappingtime = 0
    xmlParsingTime = 0
    testFoldedDataTime = 0
    genrateCoraxmlTime = 0

    #os.chdir(directory)

    file_name = glob.glob(directory+'*.pdf')
    srno = 1
    for fname in file_name:
        #print fname
        srno = srno+1
        fn = fname.split('/')
        fn = fn[-1][:-4]
	#print fn
        startTime = time.time()
        startTime = time.time()
        subprocess.call("./pdftoxml.linux64.exe.1.2_7 -noImage -noImageInline " + fname + " "+temp_dir+fn+".xml", shell=True)
        pdftoxmltime += time.time()-startTime
        try:
            a_file = temp_dir+fn+".xml"
            #print a_file

            startTime = time.time()
            tree = ET.parse(a_file)
            root = tree.getroot()
            parseTime += time.time()-startTime

            startTime = time.time()
            footnotes.foot_main(root,fn)
            footnotestime += time.time()-startTime

            startTime = time.time()
            tables_figures.tab_fig_main(root,fn)
            tables_figures_time += time.time()-startTime

            startTime = time.time()
            url.url_main(root,fn)
            urltime += time.time()-startTime

            startTime = time.time()
            References_list = cit_final.mainf(root,fn)
            cit2reftime += time.time()-startTime
            
        except Exception, inst:
            print "Exception : In main"
            #print e
            print type(inst)     # the exception instance
            print inst.args      # arguments stored in .args
            print inst           # __str__ allows args to be printed directly
        
        try:
            startTime = time.time()
            chunked_root_1, modalFS = chunk.chunk_1(root)
            chunk1time += time.time()-startTime
        except Exception, inst:
            print "Exception : In chunk1"
            #print e
            print type(inst)     # the exception instance
            print inst.args      # arguments stored in .args
            print inst           # __str__ allows args to be printed directly
        
        try:
            startTime = time.time()
            chunked_root_2, max_font_size = chunk.chunk_2(chunked_root_1)
            chunk2time += time.time()-startTime
        except Exception, inst:
            print "Exception : In chunk2"
            #print e
            print type(inst)     # the exception instance
            print inst.args      # arguments stored in .args
            print inst           # __str__ allows args to be printed directly
        
        try:
            startTime = time.time()
            Secmapping.sec_main(chunked_root_1, chunked_root_2, modalFS,fn)
            secMapTime += time.time()-startTime
        except Exception, inst:
            print "Exception : In Sections"
            #print e 'title_str
            print type(inst)     # the exception instance
            print inst.args      # arguments stored in .args
            print inst           # __str__ allows args to be printed directly
        

        try:
            startTime = time.time()
            Email_new.foutMail = "0\t0\t0\n"
            email_str_for_Map = Email_new.Email_main(root,fn)
            emailTime += time.time()-startTime
        except Exception, inst:
            print "Exception : In Email"
            #print e
            print type(inst)     # the exception instance
            print inst.args      # arguments stored in .args
            print inst           # __str__ allows args to be printed directly
        
        try:
            startTime = time.time()
            Aff_new.titleNotOver = True
            Aff_new.AffiliationOutputFile = "0\t0\t0\n"
            aff_xml = Aff_new.aff_main(chunked_root_1,max_font_size,fn)
            affTime += time.time()-startTime
        except Exception, inst:
            print "Exception : In Affiliation"
            #print e
            print type(inst)     # the exception instance
            print inst.args      # arguments stored in .args
            print inst           # __str__ allows args to be printed directly
        

        try:
            startTime = time.time()
            title_str = TitleAuthor_parse.TitleAuthor_parse(root,aff_xml,fn)
            titleTime += time.time()-startTime
        except Exception, inst:
            print "Exception : In Title"
            #print e
            print type(inst)     # the exception instance
            print inst.args      # arguments stored in .args
            print inst           # __str__ allows args to be printed directly
        
        #print "Generating Title Author xml"
        try:
            startTime = time.time()
            title_author_xml = printAuthor.printAuthor(title_str,aff_xml,fn)
            authorTime += time.time()-startTime
        except Exception, inst:
            print "Exception : In Author"
            #print e
            print type(inst)     # the exception instance
            print inst.args      # arguments stored in .args
            print inst           # __str__ allows args to be printed directly
        
        
        try:
           startTime = time.time()
           name_for_map = printnameformap.genAuthorFileForMap(title_author_xml)
           authorEmailMapping.authorEmailMap(name_for_map,email_str_for_Map,fn)         
           mappingtime += time.time()-startTime
        except Exception, inst:
           print "Exception : In Email_Author_Matching"
           #print e
           print type(inst)     # the exception instance
           print inst.args      # arguments stored in .args
           print inst           # __str__ allows args to be printed directly

        #try:
        #    xml = generate_xml.main()
        #except Exception, inst:
        #    print "Exception : In XML generation"
        #    #print e
        #    print type(inst)     # the exception instance
        #    print inst.args      # arguments stored in .args
        #    print inst           # __str__ allows args to be printed directly
        
        
    #subprocess.call("./eval_op.sh", shell=True)
    

runScript()
