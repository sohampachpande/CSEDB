Directory=/var/www/html/OCR++/myproject/media/documents

python $Directory/create_eval_title.py
python $Directory/create_eval_name.py
python $Directory/create_eval_Affiliation.py
python $Directory/create_eval_Email.py
python $Directory/create_eval_map.py
python $Directory/create_eval_tables_figures.py
python $Directory/create_eval_url.py
python $Directory/create_eval_sections.py
python $Directory/create_eval_footnote.py
python $Directory/create_eval_cit2ref.py