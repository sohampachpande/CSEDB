Directory=.

rm $Directory/eval_title.txt
rm $Directory/eval_map.txt
rm $Directory/eval_Secmap.txt
rm $Directory/eval_author.txt
rm $Directory/eval_url.txt
rm $Directory/eval_footnote.txt
rm $Directory/eval_emails.txt
rm $Directory/eval_tables_figures.txt
rm $Directory/eval_Affiliations.txt
rm $Directory/TitleAuthor.xml
rm $Directory/test.txt
rm $Directory/final.txt
rm $Directory/final_aut.txt