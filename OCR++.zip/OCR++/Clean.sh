Directory="/var/www/html/OCR++/myproject/media/documents/"

rm $Directory/input.xml